import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─────────────────────────────────────────────
//  ENTRY POINT
// ─────────────────────────────────────────────
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const FamilySyncApp());
}

// ─────────────────────────────────────────────
//  THEME & CONSTANTS
// ─────────────────────────────────────────────
const Color kPrimary = Color(0xFF6C63FF);
const Color kSecondary = Color(0xFF48D1CC);
const Color kAccent = Color(0xFFFF6584);
const Color kDark = Color(0xFF1A1A2E);
const Color kCard = Color(0xFF16213E);
const Color kSurface = Color(0xFF0F3460);

const List<String> kRoles = [
  'Mother',
  'Father',
  'Son',
  'Daughter',
  'Grandmother',
  'Grandfather',
  'Custom',
];

const List<String> kQuantities = [
  '250g',
  '500g',
  '1kg',
  '2kg',
  '5kg',
  '10kg',
];

final FirebaseFirestore _db = FirebaseFirestore.instance;

// Helper: family doc reference
DocumentReference familyDoc(String code) =>
    _db.collection('families').doc(code);

// ─────────────────────────────────────────────
//  APP ROOT
// ─────────────────────────────────────────────
class FamilySyncApp extends StatefulWidget {
  const FamilySyncApp({super.key});

  @override
  State<FamilySyncApp> createState() => _FamilySyncAppState();
}

class _FamilySyncAppState extends State<FamilySyncApp> {
  bool _darkMode = false;

  void toggleDark(bool v) => setState(() => _darkMode = v);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Family Sync',
      debugShowCheckedModeBanner: false,
      themeMode: _darkMode ? ThemeMode.dark : ThemeMode.light,
      theme: _buildTheme(false),
      darkTheme: _buildTheme(true),
      home: SplashScreen(onToggleDark: toggleDark, isDark: _darkMode),
    );
  }

  ThemeData _buildTheme(bool dark) {
    return ThemeData(
      useMaterial3: true,
      brightness: dark ? Brightness.dark : Brightness.light,
      colorScheme: ColorScheme.fromSeed(
        seedColor: kPrimary,
        brightness: dark ? Brightness.dark : Brightness.light,
      ),
      fontFamily: 'Nunito',
      scaffoldBackgroundColor: dark ? kDark : const Color(0xFFF5F3FF),
      cardColor: dark ? kCard : Colors.white,
    );
  }
}

// ─────────────────────────────────────────────
//  SPLASH SCREEN
// ─────────────────────────────────────────────
class SplashScreen extends StatefulWidget {
  final void Function(bool) onToggleDark;
  final bool isDark;

  const SplashScreen(
      {super.key, required this.onToggleDark, required this.isDark});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoCtrl;
  late AnimationController _textCtrl;
  late Animation<double> _logoScale;
  late Animation<double> _logoFade;
  late Animation<double> _textFade;
  late Animation<Offset> _textSlide;

  @override
  void initState() {
    super.initState();
    _logoCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _textCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));

    _logoScale = CurvedAnimation(parent: _logoCtrl, curve: Curves.elasticOut)
        .drive(Tween(begin: 0.3, end: 1.0));
    _logoFade = CurvedAnimation(parent: _logoCtrl, curve: Curves.easeIn)
        .drive(Tween(begin: 0.0, end: 1.0));
    _textFade = CurvedAnimation(parent: _textCtrl, curve: Curves.easeIn)
        .drive(Tween(begin: 0.0, end: 1.0));
    _textSlide =
        CurvedAnimation(parent: _textCtrl, curve: Curves.easeOutCubic).drive(
      Tween(begin: const Offset(0, 0.4), end: Offset.zero),
    );

    _logoCtrl.forward().then((_) => _textCtrl.forward().then((_) => _check()));
  }

  Future<void> _check() async {
    await Future.delayed(const Duration(milliseconds: 600));
    final prefs = await SharedPreferences.getInstance();
    final code = prefs.getString('pairCode') ?? '';
    if (!mounted) return;
    if (code.isNotEmpty) {
      _navigate(DashboardScreen(
        pairCode: code,
        userName: prefs.getString('userName') ?? '',
        role: prefs.getString('role') ?? '',
        isHost: prefs.getBool('isHost') ?? false,
        onToggleDark: widget.onToggleDark,
        isDark: widget.isDark,
      ));
    } else {
      _navigate(WelcomeScreen(
          onToggleDark: widget.onToggleDark, isDark: widget.isDark));
    }
  }

  void _navigate(Widget page) {
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, a, __) => page,
        transitionsBuilder: (_, a, __, child) =>
            FadeTransition(opacity: a, child: child),
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  @override
  void dispose() {
    _logoCtrl.dispose();
    _textCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0F0C29), Color(0xFF302B63), Color(0xFF24243E)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              FadeTransition(
                opacity: _logoFade,
                child: ScaleTransition(
                  scale: _logoScale,
                  child: Container(
                    width: 110,
                    height: 110,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [kPrimary, kSecondary],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                            color: kPrimary.withOpacity(0.5),
                            blurRadius: 30,
                            spreadRadius: 5),
                      ],
                    ),
                    child: const Icon(Icons.home_rounded,
                        size: 56, color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 28),
              SlideTransition(
                position: _textSlide,
                child: FadeTransition(
                  opacity: _textFade,
                  child: Column(
                    children: [
                      const Text('Family Sync',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 36,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.2,
                          )),
                      const SizedBox(height: 8),
                      Text('Stay connected. Always.',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.6),
                            fontSize: 15,
                            fontWeight: FontWeight.w400,
                            letterSpacing: 0.5,
                          )),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  WELCOME / LOGIN SCREEN
// ─────────────────────────────────────────────
class WelcomeScreen extends StatefulWidget {
  final void Function(bool) onToggleDark;
  final bool isDark;

  const WelcomeScreen(
      {super.key, required this.onToggleDark, required this.isDark});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen>
    with SingleTickerProviderStateMixin {
  final _nameCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();
  String _role = 'Mother';
  String _customRole = '';
  bool _loading = false;
  late AnimationController _animCtrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _fade = CurvedAnimation(parent: _animCtrl, curve: Curves.easeIn)
        .drive(Tween(begin: 0.0, end: 1.0));
    _slide =
        CurvedAnimation(parent: _animCtrl, curve: Curves.easeOutCubic).drive(
      Tween(begin: const Offset(0, 0.08), end: Offset.zero),
    );
    _animCtrl.forward();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _codeCtrl.dispose();
    _animCtrl.dispose();
    super.dispose();
  }

  String get _effectiveRole =>
      _role == 'Custom' ? _customRole.trim() : _role;

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: kPrimary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  bool _validate({bool needCode = false}) {
    if (_nameCtrl.text.trim().isEmpty) {
      _snack('Please enter your name');
      return false;
    }
    if (_effectiveRole.isEmpty) {
      _snack('Please enter your role');
      return false;
    }
    if (needCode && _codeCtrl.text.trim().isEmpty) {
      _snack('Please enter the family code');
      return false;
    }
    return true;
  }

  Future<void> _createFamily() async {
    if (!_validate()) return;
    setState(() => _loading = true);
    try {
      final code = _generateCode();
      final memberData = {
        'name': _nameCtrl.text.trim(),
        'role': _effectiveRole,
        'isHost': true,
        'joinedAt': FieldValue.serverTimestamp(),
      };
      await familyDoc(code).set({
        'createdAt': FieldValue.serverTimestamp(),
        'hostName': _nameCtrl.text.trim(),
      });
      await familyDoc(code)
          .collection('members')
          .doc(_nameCtrl.text.trim())
          .set(memberData);
      await _savePrefs(
          code, _nameCtrl.text.trim(), _effectiveRole, true);
      _goToDashboard(code);
    } catch (e) {
      _snack('Error: $e');
    }
    setState(() => _loading = false);
  }

  Future<void> _joinFamily() async {
    if (!_validate(needCode: true)) return;
    setState(() => _loading = true);
    try {
      final code = _codeCtrl.text.trim().toUpperCase();
      final doc = await familyDoc(code).get();
      if (!doc.exists) {
        _snack('Family code not found. Check and try again.');
        setState(() => _loading = false);
        return;
      }
      final memberData = {
        'name': _nameCtrl.text.trim(),
        'role': _effectiveRole,
        'isHost': false,
        'joinedAt': FieldValue.serverTimestamp(),
      };
      await familyDoc(code)
          .collection('members')
          .doc(_nameCtrl.text.trim())
          .set(memberData);
      await _savePrefs(code, _nameCtrl.text.trim(), _effectiveRole, false);
      _goToDashboard(code);
    } catch (e) {
      _snack('Error: $e');
    }
    setState(() => _loading = false);
  }

  Future<void> _savePrefs(
      String code, String name, String role, bool isHost) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('pairCode', code);
    await prefs.setString('userName', name);
    await prefs.setString('role', role);
    await prefs.setBool('isHost', isHost);
  }

  void _goToDashboard(String code) {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardScreen(
          pairCode: code,
          userName: _nameCtrl.text.trim(),
          role: _effectiveRole,
          isHost: _codeCtrl.text.isEmpty,
          onToggleDark: widget.onToggleDark,
          isDark: widget.isDark,
        ),
      ),
    );
  }

  String _generateCode() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final rng = Random.secure();
    return List.generate(6, (_) => chars[rng.nextInt(chars.length)]).join();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0F0C29), Color(0xFF302B63), Color(0xFF24243E)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            child: FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 20),
                    // Header
                    Center(
                      child: Column(
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: const LinearGradient(
                                  colors: [kPrimary, kSecondary]),
                              boxShadow: [
                                BoxShadow(
                                    color: kPrimary.withOpacity(0.4),
                                    blurRadius: 20)
                              ],
                            ),
                            child: const Icon(Icons.home_rounded,
                                color: Colors.white, size: 40),
                          ),
                          const SizedBox(height: 12),
                          const Text('Family Sync',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 28,
                                  fontWeight: FontWeight.w800)),
                          const SizedBox(height: 4),
                          Text('Your family. One place.',
                              style: TextStyle(
                                  color: Colors.white.withOpacity(0.55),
                                  fontSize: 14)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),
                    // Glass card
                    _GlassCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _label('Your Name'),
                          _field(_nameCtrl, 'e.g. Priya', Icons.person_outline),
                          const SizedBox(height: 16),
                          _label('Your Role'),
                          _roleDropdown(),
                          if (_role == 'Custom') ...[
                            const SizedBox(height: 12),
                            _fieldRaw(
                              hint: 'Enter custom role',
                              onChanged: (v) => setState(() => _customRole = v),
                              icon: Icons.edit_outlined,
                            ),
                          ],
                          const SizedBox(height: 16),
                          _label('Family Code (for Join)'),
                          _field(_codeCtrl, 'e.g. AB3X7K',
                              Icons.link_rounded,
                              caps: true),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    // Buttons
                    _loading
                        ? const Center(
                            child: CircularProgressIndicator(color: kPrimary))
                        : Column(
                            children: [
                              _gradBtn(
                                label: 'Create Family',
                                icon: Icons.add_home_rounded,
                                colors: [kPrimary, const Color(0xFF8B5CF6)],
                                onTap: _createFamily,
                              ),
                              const SizedBox(height: 14),
                              _gradBtn(
                                label: 'Join Family',
                                icon: Icons.group_add_rounded,
                                colors: [
                                  const Color(0xFF06B6D4),
                                  kSecondary
                                ],
                                onTap: _joinFamily,
                              ),
                            ],
                          ),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(t,
            style: TextStyle(
                color: Colors.white.withOpacity(0.7),
                fontSize: 13,
                fontWeight: FontWeight.w600)),
      );

  Widget _field(TextEditingController ctrl, String hint, IconData icon,
      {bool caps = false}) {
    return TextField(
      controller: ctrl,
      textCapitalization: caps ? TextCapitalization.characters : TextCapitalization.words,
      style: const TextStyle(color: Colors.white),
      decoration: _inputDec(hint, icon),
    );
  }

  Widget _fieldRaw(
      {required String hint,
      required void Function(String) onChanged,
      required IconData icon}) {
    return TextField(
      onChanged: onChanged,
      style: const TextStyle(color: Colors.white),
      decoration: _inputDec(hint, icon),
    );
  }

  InputDecoration _inputDec(String hint, IconData icon) => InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.white.withOpacity(0.35)),
        prefixIcon: Icon(icon, color: kPrimary, size: 20),
        filled: true,
        fillColor: Colors.white.withOpacity(0.07),
        contentPadding:
            const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.15)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.white.withOpacity(0.15)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: kPrimary, width: 1.5),
        ),
      );

  Widget _roleDropdown() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.07),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.15)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _role,
          isExpanded: true,
          dropdownColor: kDark,
          style: const TextStyle(color: Colors.white, fontSize: 15),
          icon: const Icon(Icons.keyboard_arrow_down, color: kPrimary),
          items: kRoles
              .map((r) => DropdownMenuItem(
                  value: r,
                  child: Text(r,
                      style: const TextStyle(color: Colors.white))))
              .toList(),
          onChanged: (v) => setState(() => _role = v!),
        ),
      ),
    );
  }

  Widget _gradBtn(
      {required String label,
      required IconData icon,
      required List<Color> colors,
      required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: colors),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: colors.first.withOpacity(0.4),
                blurRadius: 16,
                offset: const Offset(0, 6)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: 10),
            Text(label,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

class _GlassCard extends StatelessWidget {
  final Widget child;
  const _GlassCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.07),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 20,
              spreadRadius: 2),
        ],
      ),
      child: child,
    );
  }
}

// ─────────────────────────────────────────────
//  DASHBOARD SCREEN
// ─────────────────────────────────────────────
class DashboardScreen extends StatefulWidget {
  final String pairCode;
  final String userName;
  final String role;
  final bool isHost;
  final void Function(bool) onToggleDark;
  final bool isDark;

  const DashboardScreen({
    super.key,
    required this.pairCode,
    required this.userName,
    required this.role,
    required this.isHost,
    required this.onToggleDark,
    required this.isDark,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _animCtrl.forward();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  void _go(Widget page) {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // App Bar
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            backgroundColor: kDark,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFF0F0C29),
                      Color(0xFF302B63),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 48,
                              height: 48,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: const LinearGradient(
                                    colors: [kPrimary, kSecondary]),
                              ),
                              child: Center(
                                child: Text(
                                  widget.userName.isNotEmpty
                                      ? widget.userName[0].toUpperCase()
                                      : '?',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Hello, ${widget.userName}! 👋',
                                      style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w700)),
                                  Text(widget.role,
                                      style: TextStyle(
                                          color: Colors.white.withOpacity(0.6),
                                          fontSize: 13)),
                                ],
                              ),
                            ),
                            // Settings icon
                            IconButton(
                              icon: const Icon(Icons.settings_rounded,
                                  color: Colors.white),
                              onPressed: () => _go(SettingsScreen(
                                pairCode: widget.pairCode,
                                isHost: widget.isHost,
                                onToggleDark: widget.onToggleDark,
                                isDark: widget.isDark,
                              )),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        // Family code chip
                        GestureDetector(
                          onTap: () {
                            Clipboard.setData(
                                ClipboardData(text: widget.pairCode));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text('Family code copied!'),
                                  behavior: SnackBarBehavior.floating),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(30),
                              border: Border.all(
                                  color: Colors.white.withOpacity(0.2)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.link,
                                    color: kSecondary, size: 16),
                                const SizedBox(width: 6),
                                Text('Code: ${widget.pairCode}',
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 1.5)),
                                const SizedBox(width: 6),
                                const Icon(Icons.copy_rounded,
                                    color: Colors.white54, size: 14),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          // Members row
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionTitle('Family Members'),
                  const SizedBox(height: 12),
                  _MembersRow(pairCode: widget.pairCode),
                  const SizedBox(height: 24),
                  _sectionTitle('Quick Actions'),
                ],
              ),
            ),
          ),
          // Grid
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverGrid(
              delegate: SliverChildListDelegate([
                _DashCard(
                  icon: Icons.shopping_cart_rounded,
                  label: 'Grocery',
                  gradient: const [Color(0xFF6C63FF), Color(0xFF8B5CF6)],
                  onTap: () => _go(GroceryPage(
                    pairCode: widget.pairCode,
                    userName: widget.userName,
                    role: widget.role,
                  )),
                ),
                _DashCard(
                  icon: Icons.campaign_rounded,
                  label: 'Announcements',
                  gradient: const [Color(0xFF06B6D4), Color(0xFF48D1CC)],
                  onTap: () => _go(InformationPage(
                    pairCode: widget.pairCode,
                    userName: widget.userName,
                    role: widget.role,
                  )),
                ),
                _DashCard(
                  icon: Icons.chat_bubble_rounded,
                  label: 'Private Chat',
                  gradient: const [Color(0xFFEC4899), Color(0xFFF43F5E)],
                  onTap: () => _go(PrivateChatPage(
                    pairCode: widget.pairCode,
                    myName: widget.userName,
                    myRole: widget.role,
                  )),
                ),
                _DashCard(
                  icon: Icons.group_rounded,
                  label: 'Members',
                  gradient: const [Color(0xFFF59E0B), Color(0xFFFB923C)],
                  onTap: () => _go(MembersPage(
                    pairCode: widget.pairCode,
                    userName: widget.userName,
                    isHost: widget.isHost,
                  )),
                ),
              ]),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 1.1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String t) => Text(t,
      style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w700,
          color: Theme.of(context).colorScheme.onBackground));
}

class _MembersRow extends StatelessWidget {
  final String pairCode;
  const _MembersRow({required this.pairCode});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: familyDoc(pairCode).collection('members').snapshots(),
      builder: (ctx, snap) {
        if (!snap.hasData) {
          return const SizedBox(
              height: 72,
              child: Center(child: CircularProgressIndicator()));
        }
        final docs = snap.data!.docs;
        return SizedBox(
          height: 90,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: docs.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              final name = d['name'] as String? ?? '';
              final role = d['role'] as String? ?? '';
              final isHost = d['isHost'] as bool? ?? false;
              return Column(
                children: [
                  Stack(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: _avatarColors(i),
                          ),
                          boxShadow: [
                            BoxShadow(
                                color: _avatarColors(i).first.withOpacity(0.4),
                                blurRadius: 8)
                          ],
                        ),
                        child: Center(
                          child: Text(
                            name.isNotEmpty ? name[0].toUpperCase() : '?',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      if (isHost)
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Container(
                            width: 16,
                            height: 16,
                            decoration: const BoxDecoration(
                              color: kAccent,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.star,
                                color: Colors.white, size: 10),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(name,
                      style: const TextStyle(
                          fontSize: 11, fontWeight: FontWeight.w600),
                      overflow: TextOverflow.ellipsis),
                  Text(role,
                      style: TextStyle(
                          fontSize: 10,
                          color: Theme.of(context)
                              .colorScheme
                              .onBackground
                              .withOpacity(0.5))),
                ],
              );
            },
          ),
        );
      },
    );
  }

  List<Color> _avatarColors(int i) {
    final palettes = [
      [kPrimary, const Color(0xFF8B5CF6)],
      [kSecondary, const Color(0xFF06B6D4)],
      [kAccent, const Color(0xFFEC4899)],
      [const Color(0xFFF59E0B), const Color(0xFFFB923C)],
      [const Color(0xFF10B981), const Color(0xFF34D399)],
    ];
    return palettes[i % palettes.length];
  }
}

class _DashCard extends StatefulWidget {
  final IconData icon;
  final String label;
  final List<Color> gradient;
  final VoidCallback onTap;

  const _DashCard(
      {required this.icon,
      required this.label,
      required this.gradient,
      required this.onTap});

  @override
  State<_DashCard> createState() => _DashCardState();
}

class _DashCardState extends State<_DashCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 120));
    _scale = Tween(begin: 1.0, end: 0.94).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: widget.gradient,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                  color: widget.gradient.first.withOpacity(0.4),
                  blurRadius: 12,
                  offset: const Offset(0, 5)),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(widget.icon, color: Colors.white, size: 24),
                ),
                Text(widget.label,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  GROCERY PAGE
// ─────────────────────────────────────────────
class GroceryPage extends StatefulWidget {
  final String pairCode;
  final String userName;
  final String role;

  const GroceryPage(
      {super.key,
      required this.pairCode,
      required this.userName,
      required this.role});

  @override
  State<GroceryPage> createState() => _GroceryPageState();
}

class _GroceryPageState extends State<GroceryPage> {
  final _searchCtrl = TextEditingController();
  String _searchQuery = '';

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _addItem() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _AddGrocerySheet(
        pairCode: widget.pairCode,
        userName: widget.userName,
        role: widget.role,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _gradientAppBar('Grocery List', Icons.shopping_cart_rounded),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addItem,
        backgroundColor: kPrimary,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Add Item',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchCtrl,
              onChanged: (v) => setState(() => _searchQuery = v.toLowerCase()),
              decoration: InputDecoration(
                hintText: 'Search items...',
                prefixIcon: const Icon(Icons.search),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                filled: true,
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: familyDoc(widget.pairCode)
                  .collection('grocery')
                  .orderBy('addedAt', descending: true)
                  .snapshots(),
              builder: (ctx, snap) {
                if (!snap.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final docs = snap.data!.docs.where((d) {
                  final data = d.data() as Map<String, dynamic>;
                  final name =
                      (data['item'] as String? ?? '').toLowerCase();
                  return name.contains(_searchQuery);
                }).toList();

                final pending =
                    docs.where((d) => !((d.data() as Map)['done'] ?? false)).toList();
                final done =
                    docs.where((d) => (d.data() as Map)['done'] ?? false).toList();

                return ListView(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  children: [
                    if (pending.isNotEmpty) ...[
                      _sectionHeader('Pending', kPrimary),
                      ...pending.map((d) => _GroceryCard(
                            doc: d,
                            pairCode: widget.pairCode,
                          )),
                    ],
                    if (done.isNotEmpty) ...[
                      _sectionHeader('Completed', Colors.green),
                      ...done.map((d) => _GroceryCard(
                            doc: d,
                            pairCode: widget.pairCode,
                          )),
                    ],
                    if (docs.isEmpty)
                      const Center(
                          child: Padding(
                              padding: EdgeInsets.only(top: 60),
                              child: Text('No grocery items yet.'))),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionHeader(String label, Color color) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [
          Container(
              width: 4,
              height: 16,
              decoration: BoxDecoration(
                  color: color, borderRadius: BorderRadius.circular(4))),
          const SizedBox(width: 8),
          Text(label,
              style: TextStyle(
                  fontWeight: FontWeight.w700, fontSize: 14, color: color)),
        ]),
      );
}

class _GroceryCard extends StatelessWidget {
  final QueryDocumentSnapshot doc;
  final String pairCode;

  const _GroceryCard({required this.doc, required this.pairCode});

  @override
  Widget build(BuildContext context) {
    final d = doc.data() as Map<String, dynamic>;
    final done = d['done'] as bool? ?? false;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 2,
      child: ListTile(
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Checkbox(
          value: done,
          activeColor: kPrimary,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
          onChanged: (_) {
            familyDoc(pairCode)
                .collection('grocery')
                .doc(doc.id)
                .update({'done': !done});
          },
        ),
        title: Text(d['item'] ?? '',
            style: TextStyle(
                fontWeight: FontWeight.w700,
                decoration: done ? TextDecoration.lineThrough : null)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 2),
            Row(children: [
              _chip(d['quantity'] ?? '', Icons.scale_rounded),
              const SizedBox(width: 6),
              _chip(d['date'] ?? '', Icons.calendar_today_rounded),
              const SizedBox(width: 6),
              _chip(d['time'] ?? '', Icons.access_time_rounded),
            ]),
            const SizedBox(height: 4),
            Text('${d['addedBy'] ?? ''} · ${d['role'] ?? ''}',
                style:
                    TextStyle(fontSize: 11, color: Colors.grey.shade500)),
          ],
        ),
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline_rounded, color: kAccent),
          onPressed: () => familyDoc(pairCode)
              .collection('grocery')
              .doc(doc.id)
              .delete(),
        ),
      ),
    );
  }

  Widget _chip(String label, IconData icon) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(
            color: kPrimary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 10, color: kPrimary),
          const SizedBox(width: 3),
          Text(label, style: const TextStyle(fontSize: 10, color: kPrimary)),
        ]),
      );
}

class _AddGrocerySheet extends StatefulWidget {
  final String pairCode;
  final String userName;
  final String role;

  const _AddGrocerySheet(
      {required this.pairCode, required this.userName, required this.role});

  @override
  State<_AddGrocerySheet> createState() => _AddGrocerySheetState();
}

class _AddGrocerySheetState extends State<_AddGrocerySheet> {
  final _itemCtrl = TextEditingController();
  String _qty = '1kg';
  String _date = '';
  String _time = '';

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _date =
        '${now.day}/${now.month}/${now.year}';
    _time =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (d != null) {
      setState(() => _date = '${d.day}/${d.month}/${d.year}');
    }
  }

  Future<void> _pickTime() async {
    final t = await showTimePicker(
        context: context, initialTime: TimeOfDay.now());
    if (t != null) {
      setState(() =>
          _time = '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}');
    }
  }

  Future<void> _save() async {
    if (_itemCtrl.text.trim().isEmpty) return;
    await familyDoc(widget.pairCode).collection('grocery').add({
      'item': _itemCtrl.text.trim(),
      'quantity': _qty,
      'date': _date,
      'time': _time,
      'addedBy': widget.userName,
      'role': widget.role,
      'done': false,
      'addedAt': FieldValue.serverTimestamp(),
    });
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius:
              const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
                child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2)))),
            const SizedBox(height: 16),
            const Text('Add Grocery Item',
                style:
                    TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            TextField(
              controller: _itemCtrl,
              decoration: InputDecoration(
                hintText: 'Item name',
                prefixIcon: const Icon(Icons.shopping_basket_outlined),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14)),
                filled: true,
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _qty,
              decoration: InputDecoration(
                labelText: 'Quantity',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14)),
                filled: true,
                prefixIcon: const Icon(Icons.scale_rounded),
              ),
              items: kQuantities
                  .map((q) => DropdownMenuItem(value: q, child: Text(q)))
                  .toList(),
              onChanged: (v) => setState(() => _qty = v!),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pickDate,
                  icon: const Icon(Icons.calendar_today_rounded, size: 16),
                  label: Text(_date, style: const TextStyle(fontSize: 13)),
                  style: OutlinedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12))),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pickTime,
                  icon: const Icon(Icons.access_time_rounded, size: 16),
                  label: Text(_time, style: const TextStyle(fontSize: 13)),
                  style: OutlinedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12))),
                ),
              ),
            ]),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _save,
                style: ElevatedButton.styleFrom(
                  backgroundColor: kPrimary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                child: const Text('Add to List',
                    style: TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  INFORMATION / ANNOUNCEMENTS PAGE
// ─────────────────────────────────────────────
class InformationPage extends StatefulWidget {
  final String pairCode;
  final String userName;
  final String role;

  const InformationPage(
      {super.key,
      required this.pairCode,
      required this.userName,
      required this.role});

  @override
  State<InformationPage> createState() => _InformationPageState();
}

class _InformationPageState extends State<InformationPage> {
  final _msgCtrl = TextEditingController();

  Future<void> _add() async {
    if (_msgCtrl.text.trim().isEmpty) return;
    await familyDoc(widget.pairCode).collection('information').add({
      'message': _msgCtrl.text.trim(),
      'addedBy': widget.userName,
      'role': widget.role,
      'createdAt': FieldValue.serverTimestamp(),
    });
    _msgCtrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _gradientAppBar('Announcements', Icons.campaign_rounded),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: familyDoc(widget.pairCode)
                  .collection('information')
                  .orderBy('createdAt', descending: true)
                  .snapshots(),
              builder: (ctx, snap) {
                if (!snap.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final docs = snap.data!.docs;
                if (docs.isEmpty) {
                  return const Center(child: Text('No announcements yet.'));
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: docs.length,
                  itemBuilder: (_, i) {
                    final d = docs[i].data() as Map<String, dynamic>;
                    return _AnnouncementCard(
                        data: d,
                        docId: docs[i].id,
                        pairCode: widget.pairCode,
                        myName: widget.userName);
                  },
                );
              },
            ),
          ),
          // Input
          Container(
            padding: EdgeInsets.fromLTRB(
                16, 12, 16, MediaQuery.of(context).viewInsets.bottom + 16),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 12,
                    offset: const Offset(0, -3))
              ],
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _msgCtrl,
                  decoration: InputDecoration(
                    hintText: 'Write an announcement...',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14)),
                    filled: true,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: _add,
                child: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: kPrimary,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.send_rounded,
                      color: Colors.white, size: 22),
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

class _AnnouncementCard extends StatelessWidget {
  final Map<String, dynamic> data;
  final String docId;
  final String pairCode;
  final String myName;

  const _AnnouncementCard(
      {required this.data,
      required this.docId,
      required this.pairCode,
      required this.myName});

  @override
  Widget build(BuildContext context) {
    final ts = data['createdAt'] as Timestamp?;
    final dt = ts?.toDate();
    final timeStr = dt != null
        ? '${dt.day}/${dt.month}/${dt.year}  ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}'
        : '';
    final isMe = data['addedBy'] == myName;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 2,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: [
              kPrimary.withOpacity(0.06),
              kSecondary.withOpacity(0.04)
            ],
          ),
        ),
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                    colors: [kPrimary, Color(0xFF8B5CF6)]),
              ),
              child: Center(
                  child: Text(
                      (data['addedBy'] as String? ?? ' ')[0].toUpperCase(),
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold))),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Text(data['addedBy'] ?? '',
                        style: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 13)),
                    const SizedBox(width: 6),
                    Text('· ${data['role'] ?? ''}',
                        style: TextStyle(
                            fontSize: 11, color: Colors.grey.shade500)),
                  ]),
                  const SizedBox(height: 4),
                  Text(data['message'] ?? '',
                      style: const TextStyle(fontSize: 14)),
                  const SizedBox(height: 6),
                  Text(timeStr,
                      style: TextStyle(
                          fontSize: 11, color: Colors.grey.shade400)),
                ],
              ),
            ),
            if (isMe)
              IconButton(
                icon: const Icon(Icons.delete_outline_rounded,
                    color: kAccent, size: 18),
                onPressed: () => familyDoc(pairCode)
                    .collection('information')
                    .doc(docId)
                    .delete(),
              ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  PRIVATE CHAT PAGE
// ─────────────────────────────────────────────
class PrivateChatPage extends StatefulWidget {
  final String pairCode;
  final String myName;
  final String myRole;

  const PrivateChatPage(
      {super.key,
      required this.pairCode,
      required this.myName,
      required this.myRole});

  @override
  State<PrivateChatPage> createState() => _PrivateChatPageState();
}

class _PrivateChatPageState extends State<PrivateChatPage> {
  String? _selectedMember;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _gradientAppBar('Private Chat', Icons.chat_bubble_rounded),
      body: _selectedMember == null
          ? _memberSelector()
          : _ChatView(
              pairCode: widget.pairCode,
              myName: widget.myName,
              myRole: widget.myRole,
              otherName: _selectedMember!,
              onBack: () => setState(() => _selectedMember = null),
            ),
    );
  }

  Widget _memberSelector() {
    return StreamBuilder<QuerySnapshot>(
      stream: familyDoc(widget.pairCode).collection('members').snapshots(),
      builder: (ctx, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final others = snap.data!.docs.where((d) {
          final data = d.data() as Map<String, dynamic>;
          return (data['name'] as String? ?? '') != widget.myName;
        }).toList();

        if (others.isEmpty) {
          return const Center(child: Text('No other family members yet.'));
        }

        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('Select a family member to chat with',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            ...others.map((d) {
              final data = d.data() as Map<String, dynamic>;
              final name = data['name'] as String? ?? '';
              final role = data['role'] as String? ?? '';
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: kPrimary,
                    child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?',
                        style: const TextStyle(color: Colors.white)),
                  ),
                  title: Text(name,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(role),
                  trailing: const Icon(Icons.arrow_forward_ios_rounded,
                      size: 16, color: kPrimary),
                  onTap: () => setState(() => _selectedMember = name),
                ),
              );
            }),
          ],
        );
      },
    );
  }
}

class _ChatView extends StatefulWidget {
  final String pairCode;
  final String myName;
  final String myRole;
  final String otherName;
  final VoidCallback onBack;

  const _ChatView(
      {required this.pairCode,
      required this.myName,
      required this.myRole,
      required this.otherName,
      required this.onBack});

  @override
  State<_ChatView> createState() => _ChatViewState();
}

class _ChatViewState extends State<_ChatView> {
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  String get _chatId {
    final sorted = [widget.myName, widget.otherName]..sort();
    return sorted.join('_');
  }

  Future<void> _send() async {
    if (_msgCtrl.text.trim().isEmpty) return;
    final text = _msgCtrl.text.trim();
    _msgCtrl.clear();
    await familyDoc(widget.pairCode)
        .collection('privateChats')
        .doc(_chatId)
        .collection('messages')
        .add({
      'text': text,
      'sender': widget.myName,
      'role': widget.myRole,
      'sentAt': FieldValue.serverTimestamp(),
    });
    await Future.delayed(const Duration(milliseconds: 100));
    if (_scrollCtrl.hasClients) {
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Sub-header
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          color: kPrimary.withOpacity(0.08),
          child: Row(children: [
            IconButton(
                onPressed: widget.onBack,
                icon: const Icon(Icons.arrow_back_ios_rounded,
                    size: 18, color: kPrimary)),
            CircleAvatar(
                backgroundColor: kPrimary,
                radius: 18,
                child: Text(widget.otherName[0].toUpperCase(),
                    style: const TextStyle(color: Colors.white))),
            const SizedBox(width: 10),
            Text(widget.otherName,
                style: const TextStyle(
                    fontWeight: FontWeight.w700, fontSize: 15)),
          ]),
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: familyDoc(widget.pairCode)
                .collection('privateChats')
                .doc(_chatId)
                .collection('messages')
                .orderBy('sentAt')
                .snapshots(),
            builder: (ctx, snap) {
              if (!snap.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final msgs = snap.data!.docs;
              return ListView.builder(
                controller: _scrollCtrl,
                padding: const EdgeInsets.all(16),
                itemCount: msgs.length,
                itemBuilder: (_, i) {
                  final d = msgs[i].data() as Map<String, dynamic>;
                  final isMe = d['sender'] == widget.myName;
                  final ts = d['sentAt'] as Timestamp?;
                  final dt = ts?.toDate();
                  final timeStr = dt != null
                      ? '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}'
                      : '';

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Row(
                      mainAxisAlignment: isMe
                          ? MainAxisAlignment.end
                          : MainAxisAlignment.start,
                      children: [
                        if (!isMe) ...[
                          CircleAvatar(
                              radius: 16,
                              backgroundColor: Colors.grey.shade300,
                              child: Text(
                                  (d['sender'] as String? ?? '?')[0]
                                      .toUpperCase(),
                                  style: const TextStyle(fontSize: 12))),
                          const SizedBox(width: 8),
                        ],
                        Column(
                          crossAxisAlignment: isMe
                              ? CrossAxisAlignment.end
                              : CrossAxisAlignment.start,
                          children: [
                            Container(
                              constraints: BoxConstraints(
                                  maxWidth:
                                      MediaQuery.of(context).size.width *
                                          0.65),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 10),
                              decoration: BoxDecoration(
                                gradient: isMe
                                    ? const LinearGradient(
                                        colors: [kPrimary, Color(0xFF8B5CF6)])
                                    : null,
                                color: isMe
                                    ? null
                                    : Theme.of(context)
                                        .colorScheme
                                        .surfaceVariant,
                                borderRadius: BorderRadius.only(
                                  topLeft: const Radius.circular(18),
                                  topRight: const Radius.circular(18),
                                  bottomLeft: isMe
                                      ? const Radius.circular(18)
                                      : Radius.zero,
                                  bottomRight: isMe
                                      ? Radius.zero
                                      : const Radius.circular(18),
                                ),
                              ),
                              child: Text(d['text'] ?? '',
                                  style: TextStyle(
                                      color: isMe ? Colors.white : null,
                                      fontSize: 14)),
                            ),
                            const SizedBox(height: 3),
                            Text(timeStr,
                                style: TextStyle(
                                    fontSize: 10, color: Colors.grey.shade400)),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ),
        // Input row
        Container(
          padding: EdgeInsets.fromLTRB(
              16, 10, 16, MediaQuery.of(context).viewInsets.bottom + 16),
          color: Theme.of(context).cardColor,
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _msgCtrl,
                decoration: InputDecoration(
                  hintText: 'Message ${widget.otherName}...',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(24)),
                  filled: true,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 10),
                ),
              ),
            ),
            const SizedBox(width: 10),
            GestureDetector(
              onTap: _send,
              child: Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: kPrimary,
                  borderRadius: BorderRadius.circular(23),
                ),
                child: const Icon(Icons.send_rounded,
                    color: Colors.white, size: 20),
              ),
            ),
          ]),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────
//  MEMBERS PAGE
// ─────────────────────────────────────────────
class MembersPage extends StatelessWidget {
  final String pairCode;
  final String userName;
  final bool isHost;

  const MembersPage(
      {super.key,
      required this.pairCode,
      required this.userName,
      required this.isHost});

  Future<void> _removeMember(
      BuildContext context, String name) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Remove Member'),
        content: Text('Remove $name from the family?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Remove',
                  style: TextStyle(color: kAccent))),
        ],
      ),
    );
    if (confirm == true) {
      await familyDoc(pairCode).collection('members').doc(name).delete();
    }
  }

  Future<void> _deleteFamily(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Family'),
        content: const Text(
            'This will permanently delete all family data. Continue?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Delete',
                  style: TextStyle(color: kAccent))),
        ],
      ),
    );
    if (confirm == true) {
      await familyDoc(pairCode).delete();
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(
              builder: (_) => WelcomeScreen(
                  onToggleDark: (_) {}, isDark: false)),
          (_) => false,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _gradientAppBar('Family Members', Icons.group_rounded),
      body: StreamBuilder<QuerySnapshot>(
        stream: familyDoc(pairCode).collection('members').snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snap.data!.docs;
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length + (isHost ? 1 : 0),
            itemBuilder: (_, i) {
              if (i == docs.length) {
                return Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: ElevatedButton.icon(
                    onPressed: () => _deleteFamily(context),
                    icon: const Icon(Icons.delete_forever_rounded),
                    label: const Text('Delete Family'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kAccent,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                );
              }
              final d = docs[i].data() as Map<String, dynamic>;
              final name = d['name'] as String? ?? '';
              final role = d['role'] as String? ?? '';
              final host = d['isHost'] as bool? ?? false;

              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                elevation: 2,
                child: ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  leading: Stack(
                    children: [
                      CircleAvatar(
                        radius: 24,
                        backgroundColor: kPrimary,
                        child: Text(
                            name.isNotEmpty ? name[0].toUpperCase() : '?',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold)),
                      ),
                      if (host)
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: Container(
                            padding: const EdgeInsets.all(2),
                            decoration: const BoxDecoration(
                                color: kAccent, shape: BoxShape.circle),
                            child: const Icon(Icons.star,
                                color: Colors.white, size: 10),
                          ),
                        ),
                    ],
                  ),
                  title: Row(children: [
                    Text(name,
                        style: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 15)),
                    if (host) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                            color: kAccent.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(6)),
                        child: const Text('Host',
                            style: TextStyle(
                                fontSize: 10,
                                color: kAccent,
                                fontWeight: FontWeight.w700)),
                      ),
                    ]
                  ]),
                  subtitle: Text(role),
                  trailing: isHost && !host
                      ? IconButton(
                          icon: const Icon(Icons.person_remove_rounded,
                              color: kAccent),
                          onPressed: () => _removeMember(context, name),
                        )
                      : null,
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  SETTINGS PAGE
// ─────────────────────────────────────────────
class SettingsScreen extends StatelessWidget {
  final String pairCode;
  final bool isHost;
  final void Function(bool) onToggleDark;
  final bool isDark;

  const SettingsScreen({
    super.key,
    required this.pairCode,
    required this.isHost,
    required this.onToggleDark,
    required this.isDark,
  });

  Future<void> _logout(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (context.mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
            builder: (_) =>
                WelcomeScreen(onToggleDark: onToggleDark, isDark: isDark)),
        (_) => false,
      );
    }
  }

  Future<void> _deleteFamily(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Family'),
        content: const Text('This will permanently delete all family data.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Delete',
                  style: TextStyle(color: kAccent))),
        ],
      ),
    );
    if (confirm == true) {
      await familyDoc(pairCode).delete();
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(
              builder: (_) =>
                  WelcomeScreen(onToggleDark: onToggleDark, isDark: isDark)),
          (_) => false,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _gradientAppBar('Settings', Icons.settings_rounded),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _settingCard(
            context,
            icon: Icons.dark_mode_rounded,
            title: 'Dark Mode',
            subtitle: 'Toggle app theme',
            trailing: Switch(
              value: isDark,
              activeColor: kPrimary,
              onChanged: onToggleDark,
            ),
          ),
          const SizedBox(height: 12),
          _settingCard(
            context,
            icon: Icons.logout_rounded,
            title: 'Logout / Unpair',
            subtitle: 'Leave without deleting data',
            onTap: () => _logout(context),
          ),
          if (isHost) ...[
            const SizedBox(height: 12),
            _settingCard(
              context,
              icon: Icons.delete_forever_rounded,
              title: 'Delete Family',
              subtitle: 'Permanently delete all family data',
              iconColor: kAccent,
              onTap: () => _deleteFamily(context),
            ),
          ],
          const SizedBox(height: 24),
          Center(
            child: Column(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient:
                        const LinearGradient(colors: [kPrimary, kSecondary]),
                  ),
                  child: const Icon(Icons.home_rounded,
                      color: Colors.white, size: 28),
                ),
                const SizedBox(height: 8),
                const Text('Family Sync',
                    style: TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(height: 4),
                Text('Version 1.0.0',
                    style: TextStyle(
                        color: Colors.grey.shade500, fontSize: 12)),
                const SizedBox(height: 4),
                Text('Built with Flutter & Firebase',
                    style: TextStyle(
                        color: Colors.grey.shade400, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _settingCard(BuildContext context,
      {required IconData icon,
      required String title,
      required String subtitle,
      Widget? trailing,
      VoidCallback? onTap,
      Color? iconColor}) {
    return Card(
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 2,
      child: ListTile(
        onTap: onTap,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: (iconColor ?? kPrimary).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child:
              Icon(icon, color: iconColor ?? kPrimary, size: 22),
        ),
        title: Text(title,
            style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
        trailing: trailing ??
            (onTap != null
                ? const Icon(Icons.arrow_forward_ios_rounded,
                    size: 14, color: kPrimary)
                : null),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  SHARED HELPERS
// ─────────────────────────────────────────────
PreferredSizeWidget _gradientAppBar(String title, IconData icon) {
  return PreferredSize(
    preferredSize: const Size.fromHeight(56),
    child: Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF0F0C29), Color(0xFF302B63)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Row(children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 8),
          Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 18)),
        ]),
      ),
    ),
  );
}